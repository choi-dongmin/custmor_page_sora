
$(document).ready(function(){
  // NOTE:  nav_index 추가
  var nav_indexs = ['Home','Contact','Biography','Media','Concerts','News'];
  var bio_languges_indexs = ['English','French','Korean'];


  for (var i = 0; i < nav_indexs.length; i++) {
      $("#nav_indexs").append('<li><a href="./'+nav_indexs[i]+'.html">'+ nav_indexs[i] +'</a></li>');
  }
  for (var i = 0; i < bio_languges_indexs.length; i++) {
      $(".bio_languges").append('<li><a><label for="button_'+bio_languges_indexs[i]+'">'+bio_languges_indexs[i]+'</label></a></li>');
  }
});
